package edu.anonymous.model;

import soot.ValueBox;

import java.util.List;

public class Parameter {

    public ValueBox paramSig;

    public List<Object> units;
}
